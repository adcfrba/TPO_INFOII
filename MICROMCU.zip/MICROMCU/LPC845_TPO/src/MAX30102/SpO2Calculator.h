
#ifndef SPO2CALCULATOR_H_
#define SPO2CALCULATOR_H_

#define CALCULATE_EVERY_N_BEATS         3


uint8_t update(uint32_t irACValue, uint32_t redACValue);






#endif /* SPO2CALCULATOR_H_ */
